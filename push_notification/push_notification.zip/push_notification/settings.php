<?php

	//FCM Notification
    $fcmNotificationTopic = 'blogger_news_app_topic';

	//OneSignal Notification
    $oneSignalAppId = '00000000-0000-0000-0000-000000000000';
    $oneSignalRestApiKey = 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXX';

?>