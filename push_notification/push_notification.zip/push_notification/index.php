<?php 

	header('location: push.php');
    exit;

?>